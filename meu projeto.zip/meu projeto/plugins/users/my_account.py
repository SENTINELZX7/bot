from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)

from database import cur, save
from utils import get_info_wallet

import datetime
from typing import Union
import asyncio

@Client.on_callback_query(filters.regex(r"^user_info$"))
async def user_info(c: Client, m: CallbackQuery):
    hora_atual = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-3)))

    hora_atual_str = hora_atual.strftime('%H:%M:%S')

    data_atual = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-3)))

    data_atual_str = data_atual.strftime('%d/%m/%Y')
    
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [                
                InlineKeyboardButton("🧰 Ferramentas", callback_data="ferramenta"),
                InlineKeyboardButton("🔁 Trocar CCs", callback_data="exchange"),
            ],
            [
                InlineKeyboardButton("♻️ Termos De Trocas", callback_data="termos"),
            ],
            [
                InlineKeyboardButton("📬 Cadastrar", callback_data="swap_info"),
                InlineKeyboardButton("📭 Resgatar", callback_data="swap"),
            ],
            [
                InlineKeyboardButton("💳 Histórico", callback_data="history"),
            ],
            [     
                InlineKeyboardButton("⚙ Desenvolvimento Da Store", callback_data="dev"),
            ],
            [
                InlineKeyboardButton("💸 Resgatar Gift", callback_data="gift"),
            ],
            [
                InlineKeyboardButton("⬅️ Menu Principal", callback_data="start"),
            ],
        ]
    )

    link = f"https://t.me/{c.me.username}?start={m.from_user.id}"
    await m.edit_message_text(
        f"""<a href='https://d6xcmfyh68wv8.cloudfront.net/blog-content/uploads/2020/10/Card-pre-launch_blog-feature-image1.png'>&#8204</a><b><b>📛 Seu Nome: {m.from_user.first_name}</b>
<b>🆔 Seu ID: <code>{m.from_user.id}</code></b>

<b>🥇 Bônus De Recarga: Desativado</b>

<b>📆 Data Atual: {data_atual_str}</b>
<b>🕒 Hora Atual: {hora_atual_str}</b>

<b>🔗 - SISTEMA DE AFILIADOS COMO FUNCIONA:</b>
        
<i>📎 -  Compartilhe Seu Link Abaixo e Ganhe Saldo No Bot a Cada Vez Que Seu Filiado Adicionar Saldo:</i>

<b>🔗 - Seu link de afiliação:
<code>{link}</code></b>

<b>♻️ - A Cada Recarga Você Ganha 10% Do Que Seu Filiado Recarregar No Bot!</b>

<b>🔱 - Agora Tudo Ficou Mais Fácil, Navegue Pelos Botões Abaixo e Termos De Trocas ou Os Valores Do Aluguel De Nossos Bots!</>

<b>⬇️ - Confira Abaixo:</b>""",
        reply_markup=kb,
    )
    
@Client.on_callback_query(filters.regex(r"^gift$"))
async def gift(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
             [
                 InlineKeyboardButton("⬅️ Menu Principal", callback_data="start"),
             ],
        ]
    )
    link = f""
    await m.edit_message_text(
        f"""<b>🎁 Resgatar Gift</b>
        
<i>- Aqui você resgatar o gift com facilidade, digite seu Gift como o exemplo abaixo.</i>

<i>🏷 - Exemplo: /resgatar FOX0FCOT7OTH </i>

<i>♻️ - Não tente dar um de espertinho e tentar floodar vários códigos ao mesmo tempo, temos vários de segurança AntiFlood, Caso você Floodar irá tomar ban!</i>

{get_info_wallet(m.from_user.id)}""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^dev$"))
async def btc(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
      
            [
            	InlineKeyboardButton("🛒 ALUGUER SEU STORE", url="https://t.me/FB_HCKERZX"),
				
			],
			[
                InlineKeyboardButton("⬅️ Menu Principal", callback_data="start"),
            ],
        ]
    )
    await m.edit_message_text(
        f"""<a href='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZwK3NiWuYaWJO0iqE_cjIzX7fTBWcGRlhgQ&usqp=CAU'>&#8204</a><b>‌⚙️ | 𝗩𝗲𝗿𝘀ã𝗼 𝗱𝗼 𝗯𝗼𝘁: 𝟭.𝟮

🔰𝗔𝗧𝗨𝗔𝗟𝗜𝗭𝗔ÇÃ𝗢 : 𝟵 𝗱𝗲 𝗱𝗲𝘇𝗲𝗺𝗯𝗿𝗼 𝗱𝗲 𝟮𝟬𝟮𝟯

📃𝗜𝗡𝗙𝗢𝗥: 𝗕𝗢𝗧 𝗦𝗧𝗢𝗥𝗘 𝗕𝗟𝗔𝗖𝗞
𝗙𝗘𝗜𝗧𝗢: 𝗣𝗬𝗧𝗛𝗢𝗡
𝗣𝗜𝗫 𝗔𝗨𝗧𝗢𝗠Á𝗧𝗜𝗖𝗢 𝗔𝗧𝗨𝗔𝗟𝗜𝗭𝗔ÇÃ𝗢
𝗕𝗟𝗔𝗖𝗞𝗟𝗜𝗦𝗧 𝗙𝗟𝗢𝗢𝗗
𝗕𝗟𝗔𝗖𝗞𝗟𝗜𝗦𝗧 𝗙𝗟𝗢𝗢𝗗 𝗣𝗜𝗫
𝗣𝗔𝗜𝗡𝗘𝗟 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗢
𝗖𝗛𝗘𝗖𝗞𝗘𝗥 𝟭𝟬𝟬%
𝗦𝗜𝗦𝗧𝗘𝗠𝗔 𝗔𝗙𝗜𝗟𝗜𝗔𝗗𝗢𝗦 𝗔𝗧𝗨𝗔𝗟𝗜𝗭𝗔𝗗𝗢*
𝗛𝗜𝗦𝗧Ó𝗥𝗜𝗖𝗢
𝗢𝗨𝗧𝗥𝗢𝗦...

👑𝗔𝗟𝗨𝗚𝗨𝗘 𝗦𝗘𝗨 𝗦𝗧𝗢𝗥𝗘: @FB_HCKERZX""",
        reply_markup=kb,
    )  

@Client.on_callback_query(filters.regex(r"^history$"))
async def history(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("💳 Histórico de CC", callback_data="buy_history_cc"),
            ],
            [
                InlineKeyboardButton("💳 Histórico De CC Full", callback_data="buy_history_full"),
            ],
            [
                InlineKeyboardButton("◀️ Menu Principal", callback_data="user_info"),
            ],
        ]
    )
    await m.edit_message_text(
        f"""<a href='https://d6xcmfyh68wv8.cloudfront.net/blog-content/uploads/2020/10/Card-pre-launch_blog-feature-image1.png'>&#8204</a>♻️ - Selecione qual histórico de compras você deseja ver:</b>""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^buy_history_cc$"))
async def buy_history_cc(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("⬇️ ABAIXA HISTÓRICO", callback_data="abaixa_cc"),
            [
                InlineKeyboardButton("⬅️ Menu Principal", callback_data="user_info"),
            ],
        ]
    )
    history = cur.execute(
        "SELECT number, month, year, cvv FROM cards_sold WHERE owner = ? ORDER BY bought_date DESC LIMIT 50",
        [m.from_user.id],
    ).fetchall()

    if not history:
        cards_txt = "<b>⚠️ Não há nenhuma compra nos Registros.</b>"
    else:
        cards = []
        for card in history:
            cards.append("|".join([i for i in card]))
        cards_txt = "\n".join([f"<code>{cds}</code>" for cds in cards])

    await m.edit_message_text(
        f"""<b>💳 Histórico de compras</b>
<i>- Histórico das últimas compras.</i>

{cards_txt}""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^buy_history_full$"))
async def buy_history_full(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
             [   
               InlineKeyboardButton("⬇️ ABAIXA HISTÓRICO", callback_data="abaixa_full"),
             [
                InlineKeyboardButton("⬅️ Menu Principal", callback_data="user_info"),
            ],
        ]
    )
    history = cur.execute(
        "SELECT number, month, year, cvv, name, cpf FROM cards_sold_full WHERE owner = ? ORDER BY bought_date DESC LIMIT 50",
        [m.from_user.id],
    ).fetchall()

    if not history:
        cards_txt = "<b>⚠️ Não há nenhuma compra nos Registros.</b>"
    else:
        cards = []
        for card in history:
            cards.append("|".join([str(i) if i is not None else "" for i in card]))
        cards_txt = "\n".join([f"<code>{cds}</code>" for cds in cards])

    await m.edit_message_text(
        f"""<b>💳 Histórico de compras</b>
<i>- Histórico das últimas compras.</i>

{cards_txt}""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^swap$"))
async def swap_points(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("⬅️ Menu Principal", callback_data="user_info"),
            ],
        ]
    )

    user_id = m.from_user.id
    balance, diamonds = cur.execute(
        "SELECT balance, balance_diamonds FROM users WHERE id=?", [user_id]
    ).fetchone()

    if diamonds >= 100:
        add_saldo = round((diamonds / 2), 2)
        new_balance = round((balance + add_saldo), 2)

        txt = f"⚜️ Seus <b>{diamonds}</b> pontos foram convertidos em R$ <b>{add_saldo}</b> de saldo."

        cur.execute(
            "UPDATE users SET balance = ?, balance_diamonds=?  WHERE id = ?",
            [new_balance, 0, user_id],
        )
        return await m.edit_message_text(txt, reply_markup=kb)

    await m.answer(
        "⚠️ Você não tem pontos suficientes para realizar a troca. O mínimo é 100 pontos.",
        show_alert=True,
    )


@Client.on_callback_query(filters.regex(r"^swap_info$"))
async def swap_info(c: Client, m: CallbackQuery):
    await m.message.delete()

    cpf = await m.message.ask(
        "<b>👤 CPF da lara (válido) da lara que irá pagar</b>",
        reply_markup=ForceReply(),
        timeout=120,
    )
    name = await m.message.ask(
        "<b>👤 Nome completo do pagador</b>", reply_markup=ForceReply(), timeout=120
    )
    email = await m.message.ask(
        "<b>📧 E-mail</b>", reply_markup=ForceReply(), timeout=120
    )
    cpf, name, email = cpf.text, name.text, email.text
    cur.execute(
        "UPDATE users SET cpf = ?, name = ?, email = ?  WHERE id = ?",
        [cpf, name, email, m.from_user.id],
    )
    save()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("⬅️ Menu Principal", callback_data="start"),
            ]
        ]
    )
    await m.message.reply_text(
        "<b>✅️ Seus dados foram alterados com sucesso.</b>", reply_markup=kb
    )
    